## Instructions

1. Double click on the demo_binary folder and open the main.cpp file. Study the code. The demo shows you the binary representations of the character 'a', the integer 97 and the float 97.0. In C++, all variables are stored in binary.

2. If you don't already have a terminal window open, click below on "new terminal" to open a new terminal window.

3. To run the demo, type the following two commands into the the command line:
cd  /home/workspace/demo_binary
g++ main.cpp
./a.out